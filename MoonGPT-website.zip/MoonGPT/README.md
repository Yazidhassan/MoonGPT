# Moon (MoonGPT)

A mobile-first chat app: sidebar with chat history, message thread, bottom composer, streaming replies, copy button, and optional web search via Exa. The app says it is **Moon, created by Yazid**.

## Run it

Requires Node 18+. No npm install needed.

```bash
cp .env.example .env     # then add LLM_API_KEY (and EXA_API_KEY if you want web search)
node server.js
```

Open `http://localhost:3000`, or on your phone `http://<your-computer-ip>:3000` on the same Wi-Fi. You can also "Add to Home screen" for an app-like icon.

## Files

- `server.js`: serves the app and proxies `/api/chat` to the model and Exa. API keys stay here.
- `public/index.html`: the whole UI (HTML, CSS, JS in one file).
- `public/manifest.webmanifest`, `public/icon.svg`: PWA install metadata and icon.
- `.env.example`: configuration template.

## Changing the persona

Edit `SYSTEM_PROMPT` in `server.js`.

## Turning it into an Android APK later

The phone app is a web view, so it needs the server online somewhere reachable (for example a VPS, Render, or Railway). Deploy `server.js` with the `.env` values set as environment variables. Then wrap the UI with Capacitor and point it at that server URL. Do not put API keys in the APK.

## Notes

- Chats are stored in the browser's localStorage on each device.
- Not yet tested with a real API key, so check the first reply end to end.

## Features

- Streaming replies with a stop button
- Regenerate the last reply, and retry after an error
- Code blocks with language label, syntax colors, and a copy button
- Chat search, date-grouped history, export to Markdown, delete, clear all
- Optional web search through Exa (toggle "Web")
- Rate limit of 20 requests per minute per IP (set `RATE_LIMIT_PER_MIN` to change)

## Deploy with Docker

```bash
docker build -t moon .
docker run -p 3000:3000 -e LLM_API_KEY=... -e LLM_BASE_URL=... -e LLM_MODEL=... -e EXA_API_KEY=... moon
```

Keys are passed as environment variables on the host, so they never go into the image.
