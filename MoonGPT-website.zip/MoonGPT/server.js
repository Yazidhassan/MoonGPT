'use strict';
// Moon server: serves the web app and proxies chat + web search so API keys never reach the browser or the phone.
// Zero dependencies. Requires Node 18+.

const http = require('http');
const fs = require('fs');
const path = require('path');

// Load .env (no dependencies). Real environment variables win over the file.
const envFile = path.join(__dirname, '.env');
if (fs.existsSync(envFile)) {
  for (const line of fs.readFileSync(envFile, 'utf8').split('\n')) {
    const m = line.match(/^\s*([A-Z0-9_]+)\s*=\s*(.*?)\s*$/i);
    if (m && process.env[m[1]] === undefined) process.env[m[1]] = m[2].replace(/^["']|["']$/g, '');
  }
}

const PORT = Number(process.env.PORT) || 3000;
const HOST = process.env.HOST || '0.0.0.0';
const PUBLIC_DIR = path.join(__dirname, 'public');

// Any OpenAI-compatible chat endpoint works here (NVIDIA NIM, Moonshot, OpenRouter, Groq, Ollama...)
const LLM_BASE_URL = (process.env.LLM_BASE_URL || 'https://integrate.api.nvidia.com/v1').replace(/\/+$/, '');
const LLM_API_KEY = process.env.LLM_API_KEY || '';
const LLM_MODEL = process.env.LLM_MODEL || 'minimaxai/minimax-m3.1-flash';
const EXA_API_KEY = process.env.EXA_API_KEY || '';

const MAX_MESSAGE_CHARS = 8000;
const MAX_HISTORY = 30;
const RATE_LIMIT_PER_MIN = Number(process.env.RATE_LIMIT_PER_MIN) || 20;

const SYSTEM_PROMPT = `You are Moon, a helpful, friendly AI assistant created by Yazid.
When someone asks who made you, who created you, or what you are, say you are Moon, created by Yazid.
Do not name or describe any underlying model, company, or provider.
If someone sincerely asks whether you are a human or an AI, be honest that you are an AI.
Be clear and well-structured. Use Markdown (lists, code blocks) when it helps. Reply in the user's language.`;

const MIME = {
  '.html': 'text/html; charset=utf-8',
  '.js': 'text/javascript; charset=utf-8',
  '.css': 'text/css; charset=utf-8',
  '.svg': 'image/svg+xml',
  '.png': 'image/png',
  '.json': 'application/json',
  '.webmanifest': 'application/manifest+json',
  '.ico': 'image/x-icon',
};

const SECURITY_HEADERS = {
  'X-Content-Type-Options': 'nosniff',
  'Referrer-Policy': 'no-referrer',
  'X-Frame-Options': 'SAMEORIGIN',
};

// Simple in-memory per-IP rate limit (sliding 60s window).
const hits = new Map();
function rateLimited(ip) {
  const now = Date.now();
  const arr = (hits.get(ip) || []).filter((t) => now - t < 60000);
  arr.push(now);
  hits.set(ip, arr);
  if (hits.size > 5000) hits.clear();
  return arr.length > RATE_LIMIT_PER_MIN;
}

function clientIp(req) {
  return (req.headers['x-forwarded-for'] || '').split(',')[0].trim() || req.socket.remoteAddress || 'unknown';
}

function sendJson(res, status, obj) {
  res.writeHead(status, {
    'Content-Type': 'application/json; charset=utf-8',
    'Cache-Control': 'no-store',
    ...SECURITY_HEADERS,
  });
  res.end(JSON.stringify(obj));
}

function readBody(req, limit = 1_000_000) {
  return new Promise((resolve, reject) => {
    let size = 0;
    const chunks = [];
    req.on('data', (c) => {
      size += c.length;
      if (size > limit) {
        const err = new Error('Payload too large');
        err.status = 413;
        reject(err);
        req.destroy();
      } else chunks.push(c);
    });
    req.on('end', () => resolve(Buffer.concat(chunks).toString('utf8')));
    req.on('error', reject);
  });
}

function serveStatic(req, res) {
  const urlPath = decodeURIComponent(new URL(req.url, 'http://x').pathname);
  const file = path.normalize(path.join(PUBLIC_DIR, urlPath === '/' ? 'index.html' : urlPath));
  if (!file.startsWith(PUBLIC_DIR + path.sep) && file !== PUBLIC_DIR) {
    res.writeHead(403, SECURITY_HEADERS);
    return res.end('Forbidden');
  }
  fs.readFile(file, (err, data) => {
    if (err) {
      res.writeHead(404, { 'Content-Type': 'text/plain', ...SECURITY_HEADERS });
      return res.end('Not found');
    }
    res.writeHead(200, {
      'Content-Type': MIME[path.extname(file)] || 'application/octet-stream',
      'Cache-Control': 'no-cache',
      ...SECURITY_HEADERS,
    });
    res.end(data);
  });
}

// Exa neural search. Endpoint and body follow Exa's public /search API; verify against your plan.
async function exaSearch(query) {
  const r = await fetch('https://api.exa.ai/search', {
    method: 'POST',
    headers: { 'x-api-key': EXA_API_KEY, 'Content-Type': 'application/json' },
    body: JSON.stringify({
      query,
      numResults: 5,
      type: 'auto',
      contents: { text: { maxCharacters: 1500 } },
    }),
  });
  if (!r.ok) throw new Error(`Exa error ${r.status}: ${(await r.text()).slice(0, 200)}`);
  const data = await r.json();
  return (data.results || []).map((x) => ({ title: x.title || x.url, url: x.url, text: x.text || x.summary || '' }));
}

async function handleChat(req, res) {
  if (rateLimited(clientIp(req))) {
    return sendJson(res, 429, { error: 'Too many requests. Wait a moment and try again.' });
  }
  let body;
  try {
    body = JSON.parse(await readBody(req));
  } catch (e) {
    return sendJson(res, e.status || 400, { error: e.message || 'Invalid JSON' });
  }
  if (!LLM_API_KEY) {
    return sendJson(res, 500, { error: 'Server is missing LLM_API_KEY. Add it to .env and restart the server.' });
  }

  const history = (Array.isArray(body.messages) ? body.messages : [])
    .filter((m) => m && (m.role === 'user' || m.role === 'assistant') && typeof m.content === 'string' && m.content.trim())
    .map((m) => ({ role: m.role, content: m.content.slice(0, MAX_MESSAGE_CHARS) }))
    .slice(-MAX_HISTORY);
  if (!history.length || history[history.length - 1].role !== 'user') {
    return sendJson(res, 400, { error: 'No user message to answer.' });
  }

  let system = SYSTEM_PROMPT;
  if (body.search) {
    const q = history[history.length - 1].content.slice(0, 300);
    if (!EXA_API_KEY) {
      system += '\n\nWeb search was requested but is not configured (missing EXA_API_KEY). Answer from your own knowledge and say so if current information matters.';
    } else {
      try {
        const results = await exaSearch(q);
        if (results.length) {
          system += '\n\nWeb search results for the latest question. Cite sources as [n] when you use them:\n' +
            results.map((r, i) => `[${i + 1}] ${r.title} (${r.url})\n${r.text}`).join('\n\n');
        }
      } catch (e) {
        system += `\n\nWeb search failed (${e.message}). Answer from your own knowledge and say so if needed.`;
      }
    }
  }

  const ctrl = new AbortController();
  res.on('close', () => { if (!res.writableEnded) ctrl.abort(); });

  let upstream;
  try {
    upstream = await fetch(`${LLM_BASE_URL}/chat/completions`, {
      method: 'POST',
      signal: ctrl.signal,
      headers: {
        Authorization: `Bearer ${LLM_API_KEY}`,
        'Content-Type': 'application/json',
        Accept: 'text/event-stream',
      },
      body: JSON.stringify({
        model: LLM_MODEL,
        messages: [{ role: 'system', content: system }, ...history],
        stream: true,
        temperature: 0.6,
        max_tokens: 4096,
      }),
    });
  } catch (e) {
    return sendJson(res, 502, { error: 'Could not reach the model server: ' + e.message });
  }
  if (!upstream.ok) {
    const t = await upstream.text();
    return sendJson(res, 502, { error: `Model error ${upstream.status}: ${t.slice(0, 300)}` });
  }

  // Re-stream only the text deltas as plain text to the client.
  res.writeHead(200, {
    'Content-Type': 'text/plain; charset=utf-8',
    'Cache-Control': 'no-cache',
    'X-Accel-Buffering': 'no',
    ...SECURITY_HEADERS,
  });
  const reader = upstream.body.getReader();
  const dec = new TextDecoder();
  let buf = '';
  try {
    for (;;) {
      const { done, value } = await reader.read();
      if (done) break;
      buf += dec.decode(value, { stream: true });
      let idx;
      while ((idx = buf.indexOf('\n')) >= 0) {
        const line = buf.slice(0, idx).trim();
        buf = buf.slice(idx + 1);
        if (!line.startsWith('data:')) continue;
        const data = line.slice(5).trim();
        if (!data || data === '[DONE]') continue;
        try {
          const delta = JSON.parse(data).choices?.[0]?.delta?.content;
          if (delta) res.write(delta);
        } catch { /* ignore malformed keep-alive lines */ }
      }
    }
  } catch { /* client aborted or upstream closed */ }
  res.end();
}

const server = http.createServer(async (req, res) => {
  const pathname = new URL(req.url, 'http://x').pathname;
  if (req.method === 'GET' && pathname === '/healthz') {
    return sendJson(res, 200, { ok: true });
  }
  if (req.method === 'GET' && pathname === '/api/config') {
    return sendJson(res, 200, {
      appName: 'Moon',
      hasLlmKey: !!LLM_API_KEY,
      searchEnabled: !!EXA_API_KEY,
    });
  }
  if (req.method === 'POST' && pathname === '/api/chat') {
    return handleChat(req, res).catch((e) => {
      if (!res.headersSent) sendJson(res, 500, { error: e.message });
      else res.end();
    });
  }
  if (req.method === 'GET' || req.method === 'HEAD') return serveStatic(req, res);
  res.writeHead(405, SECURITY_HEADERS);
  res.end();
});

server.listen(PORT, HOST, () => console.log(`Moon running on http://${HOST}:${PORT}`));
